package com.ldt.musicr.model;

public abstract class Media {
   public static final int SONG = 1;
   public static final int ARTIST = 2;
    public static final int  GENRE = 3;
    public static final int  PLAYLIST = 4;
    public static final int  ALBUM = 5;
}
